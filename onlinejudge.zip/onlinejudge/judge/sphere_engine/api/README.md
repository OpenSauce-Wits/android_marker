# php-client

[![Build Status](https://travis-ci.org/sphere-engine/php-client.svg?branch=master)](https://travis-ci.org/sphere-engine/php-client)

The Sphere Engine platform features 60+ compilers of all the most popular programming languages. Starting from now, you can forget about setting up, maintaining and updating your own programming environment.

Our service lets you compile code online through our servers. The possibilities are endless: from mobile apps to education to online-enabled IDE's.

http://www.sphere-engine.com

All copyrights of this api goes to [sphere-engine.com](https://www.sphere-engine.com).

API Source Control [php-client](https://github.com/sphere-engine/php-client/tree/master/Examples)
