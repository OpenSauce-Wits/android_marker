# CalculatorApplication
Basic calculator with no post-fix functionality

# Build Status
[![Build Status](https://app.bitrise.io/app/6d2d18b9dbb13194/status.svg?token=vd8EaLvKI8S8KdG6Ei-XIQ)](https://app.bitrise.io/app/6d2d18b9dbb13194)

# Code Coverage
[![Coverage Status](https://coveralls.io/repos/github/OpenSauce-Wits/CalculatorApplication/badge.svg?branch=master)](https://coveralls.io/github/OpenSauce-Wits/CalculatorApplication?branch=master)
