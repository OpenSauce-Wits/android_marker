<?php
$cwd=getcwd();
echo $cwd;
?>
