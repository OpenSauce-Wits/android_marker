#include <stdio.h>
#include <stdlib.h>
int main(){
    int n;

    scanf("%d", &n);
//    sleep(20);
    printf("Hello %d\n",n);

}
