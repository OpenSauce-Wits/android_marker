<?php
/*
<html>
	<form action="https://wits2.rklein.me/test/pluginfile.php/2803/assignfeedback_witsoj/oj_testcases/0/view.zip" method="post">
		<input type="hidden" name="witsoj_token" id="witsoj_token" value="1e6947ac7fb3a9529a9726eb692c8cc5">
		<input type="submit" value="Submit">
	</form>
</html>
