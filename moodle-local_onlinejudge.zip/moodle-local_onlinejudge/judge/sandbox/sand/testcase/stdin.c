#include <stdio.h>

int main(void)
{
    int c;
    while ( (c = getchar()) != EOF)
        ;
    return 0;
}
