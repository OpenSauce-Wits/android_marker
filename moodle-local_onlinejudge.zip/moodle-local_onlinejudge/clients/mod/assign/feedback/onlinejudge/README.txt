All files and subdirectories of this directory must be placed in MOODLE/mod/assign/feedback/onlinejudge
